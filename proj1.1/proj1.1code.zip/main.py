
# coding: utf-8

# ## Logic Based FizzBuzz Function [Software 1.0]

# In[1]:


import pandas as pd

def fizzbuzz(n):
    
    # Logic Explanation
    if n % 3 == 0 and n % 5 == 0:
        return 'FizzBuzz'
    elif n % 3 == 0:
        return 'Fizz'
    elif n % 5 == 0:
        return 'Buzz'
    else:
        return 'Other'


# ## Create Training and Testing Datasets in CSV Format

# In[2]:


def createInputCSV(start,end,filename):
    
    # Why list in Python?
    #Answer: Beacuse list is changeable and allow duplicate member. These feature makes programer easy to modifie their input for traning the model. 
    inputData   = []
    outputData  = []
    
    # Why do we need training Data?
    #Answer: Training data sets are sets on which I train my machine. Include both the input data together along with the corresponding expected output. 
   # This provides my model with “ground truth” data. My model would updata some of its parameter base on the training data I provide. 
    for i in range(start,end):
        inputData.append(i)
        outputData.append(fizzbuzz(i))
    
    # Why Dataframe?
    #Answer: The dataframe labeled columns, plus indexing on the rows. We can apply an operation by simply call the label name. 
    #We can also find the dulipicate or group by key. 
    dataset = {}
    dataset["input"]  = inputData
    dataset["label"] = outputData
    
    # Writing to csv
    pd.DataFrame(dataset).to_csv(filename)
    
    print(filename, "Created!")


# ## Processing Input and Label Data

# In[3]:


def processData(dataset):
    
    # Why do we have to process?
    # Answer: It makes the data into a form that I can work
    data   = dataset['input'].values
    labels = dataset['label'].values
    
    processedData  = encodeData(data)
    processedLabel = encodeLabel(labels)
    
    return processedData, processedLabel


# In[4]:


def encodeData(data):
    
    processedData = []
    
    for dataInstance in data:
        
        # Why do we have number 10?
        # Answer: We need to turn each input into a vector of activations. Represent each input by an array of its binary digits.
        processedData.append([dataInstance >> d & 1 for d in range(10)])
    
    return np.array(processedData)


# In[5]:


from keras.utils import np_utils

def encodeLabel(labels):
    
    processedLabel = []
    
    for labelInstance in labels:
        if(labelInstance == "FizzBuzz"):
            # Fizzbuzz
            processedLabel.append([3])
        elif(labelInstance == "Fizz"):
            # Fizz
            processedLabel.append([1])
        elif(labelInstance == "Buzz"):
            # Buzz
            processedLabel.append([2])
        else:
            # Other
            processedLabel.append([0])

    return np_utils.to_categorical(np.array(processedLabel),4)


# ## Model Definition

# In[6]:


from keras.models import Sequential
from keras.layers import Dense, Activation, Dropout
from keras.callbacks import EarlyStopping, TensorBoard
from keras.layers import LeakyReLU 
import numpy as np

input_size = 10
drop_out = 0.2
first_dense_layer_nodes  = 256

second_dense_layer_nodes = 4

def get_model():
    
    # Why do we need a model?
    #Answer:  ML model refers to the model artifact that is created by the training process
    # I can use the model to get predictions on new data for which I do not know the target. 
    #In this project, I  will using the model to predict if the number is Fizz, Buzz, FizzBuzz or Other. 
    
    # Why use Dense layer and then activation?
    # Answer: I could retrieve the outputs of the last layer (before activation) out of defined model.
    
    # Why use sequential model with layers?
    #Answer: I could  reate the models layer-by-layer . For this FizzBuzz problem, I only have 1 input type, 
    #and don't have to produce multiple output destinations. So choose sequential model will be the easist way to do. 
    model = Sequential()
    
    model.add(Dense(first_dense_layer_nodes, input_dim=input_size))
    model.add(Activation('relu'))
   
    # Why dropout?
    #Answer: We simply turn-off some of the hidden units (with some probability) so that the hidden units don’t learn every redundant 
    #detail of instances in training set. Beacause the available data often has non-linear underlying patterns which can only be 
    #extracted by using a non-linear approximation function. when the hidden units try to approximate a function for these samples, 
    #they tend to fit a higher order approximator and by doing so, they overfit to the data-samples.
    model.add(Dropout(drop_out))
    
    model.add(Dense(second_dense_layer_nodes))
    model.add(Activation('softmax'))
              
    # Why Softmax?
    #Answer:  Because Softmax function calculates probability of label for the input data, and answers one with the highest probability. 
    #It is used for classifying between classes having an idea of the probabilities of each class.
    model.summary()
    
    # Why use categorical_crossentropy?
    #Answer: Because it is what we use to measure the error at a softmax layer. The softmax function outputs a categorical distribution over outputs. 
    
    model.compile(optimizer='rmsprop',
                  loss='categorical_crossentropy',
                  metrics=['accuracy'])
    
    return model


# # <font color='blue'>Creating Training and Testing Datafiles</font>

# In[7]:


# Create datafiles
createInputCSV(101,1001,'training.csv')
createInputCSV(1,101,'testing.csv')


# # <font color='blue'>Creating Model</font>

# In[8]:


model = get_model()


# # <font color = blue>Run Model</font>

# In[9]:


validation_data_split = 0.2
num_epochs = 10000 
model_batch_size = 128 
tb_batch_size = 32 
early_patience = 100 

tensorboard_cb   = TensorBoard(log_dir='logs', batch_size= tb_batch_size, write_graph= True)
earlystopping_cb = EarlyStopping(monitor='val_loss', verbose=1, patience=early_patience, mode='min')

# Read Dataset
dataset = pd.read_csv('training.csv')

# Process Dataset
processedData, processedLabel = processData(dataset)
history = model.fit(processedData
                    , processedLabel
                    , validation_split=validation_data_split
                    , epochs=num_epochs
                    , batch_size=model_batch_size
                    , callbacks = [tensorboard_cb,earlystopping_cb]
                   )


# # <font color = blue>Training and Validation Graphs</font>

# In[10]:


get_ipython().run_line_magic('matplotlib', 'inline')
df = pd.DataFrame(history.history)
df.plot(subplots=True, grid=True, figsize=(10,15))


# # <font color = blue>Testing Accuracy [Software 2.0]</font>

# In[11]:


def decodeLabel(encodedLabel):
    if encodedLabel == 0:
        return "Other"
    elif encodedLabel == 1:
        return "Fizz"
    elif encodedLabel == 2:
        return "Buzz"
    elif encodedLabel == 3:
        return "FizzBuzz"


# In[12]:


wrong   = 0
right   = 0

testData = pd.read_csv('testing.csv')

processedTestData  = encodeData(testData['input'].values)
processedTestLabel = encodeLabel(testData['label'].values)
predictedTestLabel = []

for i,j in zip(processedTestData,processedTestLabel):
    y = model.predict(np.array(i).reshape(-1,10))
    predictedTestLabel.append(decodeLabel(y.argmax()))
    
    if j.argmax() == y.argmax():
        right = right + 1
    else:
        wrong = wrong + 1

print("Errors: " + str(wrong), " Correct :" + str(right))

print("Testing Accuracy: " + str(right/(right+wrong)*100))

# Please input your UBID and personNumber 
testDataInput = testData['input'].tolist()
testDataLabel = testData['label'].tolist()

testDataInput.insert(0, "UBID")
testDataLabel.insert(0, "haoquanz")

testDataInput.insert(1, "personNumber")
testDataLabel.insert(1, "50189594")

predictedTestLabel.insert(0, "")
predictedTestLabel.insert(1, "")

output = {}
output["input"] = testDataInput
output["label"] = testDataLabel

output["predicted_label"] = predictedTestLabel

opdf = pd.DataFrame(output)
opdf.to_csv('output.csv')

